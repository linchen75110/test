<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'shequ');
define('UC_DBPW', 'shequ');
define('UC_DBNAME', 'shequ');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`shequ`.mn_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'D0tas5c5A4RaAcz3k198zci2cbf3gbIbx7z1Vbj0G3NdSb60IdmcPbL5CdV4wcK3');
define('UC_API', 'http://www.dz.com/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>