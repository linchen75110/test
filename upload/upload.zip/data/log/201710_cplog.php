<?PHP exit;?>	1508380438	mnadmin	1	127.0.0.1		GET={}; POST={};
<?PHP exit;?>	1508380439	mnadmin	1	127.0.0.1	index	GET={}; POST={};
<?PHP exit;?>	1508380440	mnadmin	1	127.0.0.1	checktools	GET={operation=filecheck; homecheck=yes; inajax=1; ajaxtarget=filecheck_div; }; POST={};
<?PHP exit;?>	1508380448	mnadmin	1	127.0.0.1	checktools	GET={operation=filecheck; step=3; }; POST={};
<?PHP exit;?>	1508380530	mnadmin	1	127.0.0.1	nav	GET={}; POST={};
<?PHP exit;?>	1508380532	mnadmin	1	127.0.0.1	styles	GET={}; POST={};
