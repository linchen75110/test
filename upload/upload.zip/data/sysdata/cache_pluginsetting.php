<?php
//Discuz! cache file, DO NOT modify me!
//Identify: aa70aed2835e7b0d2d931d7806665693

$pluginsetting = array (
);
?>